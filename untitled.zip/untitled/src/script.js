// JavaScript for handling login and dashboard switching

// Show Teacher Login Form
document.getElementById("teacherButton").addEventListener("click", function() {
    // Hide the welcome page and show the Teacher Login form
    document.querySelector(".container").style.display = "none";
    document.getElementById("teacherLogin").style.display = "block";
});

// Show Student Dashboard
document.getElementById("studentButton").addEventListener("click", function() {
    // Hide the welcome page and show the Student Dashboard
    document.querySelector(".container").style.display = "none";
    document.getElementById("studentDashboard").style.display = "block";
});

// Teacher Login Logic
document.getElementById("teacherLoginButton").addEventListener("click", function() {
    var teacherName = document.getElementById("teacherName").value;
    var subjectCode = document.getElementById("teacherSubjectCode").value;
    if (teacherName && subjectCode) {
        // Store teacher's name and show the teacher dashboard
        document.getElementById("teacherNameDisplay").innerText = teacherName;
        document.getElementById("teacherLogin").style.display = "none";
        document.getElementById("teacherDashboard").style.display = "block";
    } else {
        alert("Please enter both name and subject code.");
    }
});

// Logic for adding students
document.getElementById("addStudent").addEventListener("click", function() {
    var studentName = document.getElementById("studentName").value;
    var studentCode = document.getElementById("studentCode").value;
    if (studentName && studentCode) {
        var studentList = document.getElementById("studentList");
        var li = document.createElement("li");
        li.textContent = `Name: ${studentName}, Code: ${studentCode}`;
        studentList.appendChild(li);
        
        document.getElementById("studentName").value = '';
        document.getElementById("studentCode").value = '';
    } else {
        alert("Please enter both student name and student code.");
    }
});

// Logic for student dashboard
document.getElementById("joinClass").addEventListener("click", function() {
    var studentName = document.getElementById("studentNameInput").value;
    var subjectCode = document.getElementById("studentSubjectCode").value;
    if (studentName && subjectCode) {
        alert("Welcome, " + studentName + ". You have joined the class with the subject code " + subjectCode + ".");
    } else {
        alert("Please enter both name and subject code.");
    }
});

// Teacher functionality for posting questions
document.getElementById("postQuestion").addEventListener("click", function() {
    var question = document.getElementById("teacherQuestions").value;
    if (question) {
        alert("Question posted successfully!");
    } else {
        alert("Please enter a question.");
    }
});

// Teacher functionality for posting announcements
document.getElementById("postAnnouncement").addEventListener("click", function() {
    var announcement = document.getElementById("teacherAnnouncements").value;
    if (announcement) {
        alert("Announcement posted successfully!");
    } else {
        alert("Please enter an announcement.");
    }
});

// AI Tool Logic (for demonstration purposes)
document.getElementById("getAIResponse").addEventListener("click", function() {
    var aiInput = document.getElementById("aiInput").value;
    if (aiInput) {
        document.getElementById("aiOutput").textContent = "AI Response: This is a simulated answer.";
    } else {
        alert("Please ask a question for the AI.");
    }
});
